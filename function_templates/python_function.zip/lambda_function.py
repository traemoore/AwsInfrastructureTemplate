import json

def lambda_handler(event, context):
    # Log the received event in CloudWatch
    print(f"Received event: {json.dumps(event)}")

    # Sample response
    response = {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Hello from Lambda!",
        }),
        "headers": {
            "Content-Type": "application/json"
        }
    }

    return response
